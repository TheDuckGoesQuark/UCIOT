#!/usr/bin/env bash

mkdir ~/killswitch


