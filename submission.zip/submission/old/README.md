# README

On-Demand
- flood with routing request when destination unknown
- recipients that don't know path will append themselves to path message before replying

